const monthYear = document.getElementById('monthYear');
const daysContainer = document.getElementById('days');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');

let currentDate = new Date();

function renderCalendar(date) {
  daysContainer.innerHTML = "";

  const year = date.getFullYear();
  const month = date.getMonth();

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  // Set header text
  monthYear.textContent = `${monthNames[month]} ${year}`;

  // First day of the month
  const firstDayOfMonth = new Date(year, month, 1);
  const startDay = firstDayOfMonth.getDay();

  // Number of days in current and previous month
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  // Fill in days from the previous month
  for (let i = startDay - 1; i >= 0; i--) {
    const dayDiv = document.createElement('div');
    dayDiv.classList.add('day', 'other-month');
    dayDiv.textContent = daysInPrevMonth - i;
    daysContainer.appendChild(dayDiv);
  }

  // Fill in current month's days
  for (let i = 1; i <= daysInMonth; i++) {
    const dayDiv = document.createElement('div');
    dayDiv.classList.add('day');
    dayDiv.textContent = i;

    // Highlight today
    const today = new Date();
    if (
      i === today.getDate() &&
      month === today.getMonth() &&
      year === today.getFullYear()
    ) {
      dayDiv.classList.add('today');
    }

    daysContainer.appendChild(dayDiv);
  }

  // Fill in next month's days to complete 6 weeks (42 cells)
  const totalCells = startDay + daysInMonth;
  const remainingCells = 42 - totalCells;
  for (let i = 1; i <= remainingCells; i++) {
    const dayDiv = document.createElement('div');
    dayDiv.classList.add('day', 'other-month');
    dayDiv.textContent = i;
    daysContainer.appendChild(dayDiv);
  }
}

// Handle previous/next month buttons
prevBtn.addEventListener('click', () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar(currentDate);
});

nextBtn.addEventListener('click', () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar(currentDate);
});

// First load
renderCalendar(currentDate);